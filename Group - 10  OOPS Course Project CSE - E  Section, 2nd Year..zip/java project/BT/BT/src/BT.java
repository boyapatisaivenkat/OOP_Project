import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
class BT{
    BT(){
        JFrame f=new JFrame("Project");
        JLabel label1=new JLabel("BUS RESERVATION SYSTEM");
        JLabel label=new JLabel("Username");
        JTextField text1=new JTextField("");
        JLabel label2=new JLabel("Password");
        JPasswordField text2=new JPasswordField("");
        JButton b=new JButton("Login");
        label1.setBounds(300,105,500,30);
        label1.setFont(new Font("Arial",Font.PLAIN,30));
        label1.setForeground(Color.blue);
        f.getContentPane().setBackground(Color.yellow);
        f.add(label1);
        label.setBounds(340,200,95,30);
        label.setForeground(Color.red);
        f.add(label);
        text1.setBounds(440,200,130,30);
        f.add(text1);
        label2.setBounds(340,250,95,30);
        label2.setForeground(Color.green);
        f.add(label2);
        text2.setBounds(440,250,130,30);
        f.add(text2);
        b.setBounds(455,305,95,30);
        f.add(b);
        b.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                String uname=text1.getText();
                String psd=text2.getText();
                if(uname.equals("BOYAPATI")&&psd.equals("123"))
                {
                    b.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent ae){
                            f.dispose();
                            new Railways();
                        }});
                }
                else{JOptionPane.showMessageDialog(f,"hint:BOYAPATI,123");
                }
            }
        });
        f.setSize(900,600);
        f.setLayout(null);
        f.setVisible(true);
        f.setResizable(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String[]args)
    {new BT();
    }
}
class Railways{
    int amount=0;
    JFrame f=new JFrame("Bus Reservation ");
    public Railways()
    {
        JLabel l=new JLabel("RESERVATION");
        JLabel label=new JLabel(" Departure from:");
        JTextField text1=new JTextField();
        JLabel label2=new JLabel(" Destination Point:");
        JTextField text2=new JTextField();
        JLabel l3=new JLabel(" Gender: ");
        JRadioButton j1=new JRadioButton("male");
        JRadioButton j2=new JRadioButton("Female");
        JLabel l4=new JLabel("Bus: ");
        String s1[]={"SELECT","Sleeper","Seater"};
        JLabel l6=new JLabel("TIMINGS :");
        String s11[]={"SELECT","9:00AM","10:00AM","11:00AM","1:30PM","3:30PM","6:00PM","8:00PM","10:00PM","11:55PM"};
        JComboBox t33=new JComboBox(s11);
        JLabel l61=new JLabel("Seats type:");
        JRadioButton j10=new JRadioButton("Upper");
        JRadioButton j20=new JRadioButton("Lower");
        ButtonGroup G=new ButtonGroup();
        G.add(j10);
        G.add(j20);
        JLabel l5=new JLabel("Select no of seats: ");
        Choice ch=new Choice();
        ch.add("zero");
        ch.add("one");
        ch.add("two");
        ch.add("three");
        JLabel l611=new JLabel("Select no.of window seats :");
        Choice ch1=new Choice();
        ch1.add("zero");
        ch1.add("one");
        ch1.add("two");
        ch1.add("three");
        JLabel l333=new JLabel(" A/c NON a/c :");
        JRadioButton j11=new JRadioButton("AC");
        JRadioButton j22=new JRadioButton("NON-AC");
        ButtonGroup p=new ButtonGroup();
        p.add(j11);
        p.add(j22);
        JButton b=new JButton("Submit");
        b.setBounds(191,630,95,20);
        f.add(b);
        l.setFont(new Font("Arial",Font.PLAIN,30));
        l.setBounds(150,70,250,30);
        f.add(l);
        label.setBounds(50,150,105,30);
        f.add(label);
        text1.setBounds(175,157,100,20);
        f.add(text1);
        label2.setBounds(50,170,150,95);
        f.add(label2);
        text2.setBounds(175,207,100,20);
        f.add(text2);
        l3.setBounds(50,250,95,30);
        f.add(l3);
        j1.setBounds(150,250,95,30);
        f.add(j1);
        j2.setBounds(250,250,95,30);
        f.add(j2);
        ButtonGroup H=new ButtonGroup();
        H.add(j1);
        H.add(j2);
        l4.setBounds(50,300,135,30);
        f.add(l4);
        JComboBox t3=new JComboBox(s1);
        t3.setBounds(175,310,100,20);
        f.add(t3);
        l6.setBounds(50,370,135,30);
        f.add(l6);
        t33.setBounds(175,375,100,20);
        f.add(t33);
        l61.setBounds(50,410,150,30);
        f.add(l61);
        j10.setBounds(150,410,95,30);
        f.add(j10);
        j20.setBounds(250,410,95,30);
        f.add(j20);
        l5.setBounds(50,450,145,30);
        f.add(l5);
        ch.setBounds(200,460,100,20);
        f.add(ch);
        l611.setBounds(55,500,165,30);
        f.add(l611);
        ch1.setBounds(220,510,100,20);
        f.add(ch1);
        l333.setBounds(50,560,135,30);
        f.add(l333);
        j11.setBounds(160,560,140,35);
        f.add(j11);
        j22.setBounds(260,560,140,35);
        f.add(j22);
        b.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                String d= ch.getItem(ch.getSelectedIndex());
                String d1= ch1.getItem(ch1.getSelectedIndex());
                if(d=="zero"){
                    amount=0;
                }
                if(d=="one"){
                    amount=700;
                }
                if(d=="two"){
                    amount=1400;
                }
                if(d=="three"){
                    amount=2100;
                }
                if(d1=="zero"){
                    amount=amount+0;
                }
                if(d1=="one"){
                    amount=amount+800;
                }
                if(d1=="two"){
                    amount=amount+1600;
                }
                if(d1=="three"){
                    amount=amount+2400;
                }
                String str2 = Integer.toString(amount);
                String str3="Total amount is ";
                JOptionPane.showMessageDialog(null,str3+str2);
                f.dispose();
                new Details();
            }
        });
        f.setSize(500,800);
        f.setLayout(null);
        f.setVisible(true);
        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
//*****PASSENGER DETAILS***********
class Details extends Railways{
    JFrame f=new JFrame("PASSENGER DETAILS");
    public Details()
    {JLabel label;
        JLabel l=new JLabel("PASSENGER DETAILS");
        JLabel la =new JLabel("Name :");
        JTextField text1=new JTextField("");
        JLabel label2=new JLabel("Age : ");
        JTextField text2=new JTextField();
        JLabel l3=new JLabel("Gender :");
        Choice ch3=new Choice();
        ch3.add("male");
        ch3.add("female");
        JLabel l6=new JLabel("Confirm password : ");
        JTextField  t5= new JPasswordField();
        JLabel label6=new JLabel("Mobile number   :");
        JTextField  text15= new JTextField();
        JLabel l5=new JLabel("PaymentMode:");
        Choice ch2=new Choice();
        ch2.add("PAYTM");
        ch2.add("GPAY");
        ch2.add("PHONEPE");
        ch2.add("CREDIT CARD");
        ch2.add("DEBIT CARD");
        JButton b=new JButton("Submit");
        l.setFont(new Font("Arial",Font.PLAIN,20));
        l.setBounds(150,70,250,30);
        f.add(l);
        la.setBounds(50,150,95,30);
        f.add(la);
        text1.setBounds(175,157,100,20);
        f.add(text1);
        label2.setBounds(50,200,80,30);
        f.add(label2);
        text2.setBounds(175,207,30,20);
        f.add(text2);
        l3.setBounds(50,250,95,30);
        f.add(l3);
        ch3.setBounds(150,250,95,30);
        f.add(ch3);
        l6.setBounds(50,300,150,30);
        f.add(l6);
        t5.setBounds(175,310,95,20);
        f.add(t5);
        label6.setBounds(50,350,135,30);
        f.add(label6);
        text15.setBounds(175,360,95,20);
        f.add(text15);
        l5.setBounds(50,400,135,30);
        f.add(l5);
        ch2.setBounds(185,410,100,20);
        f.add(ch2);
        b.setBounds(200,520,95,20);
        f.add(b);
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                {
                    JOptionPane.showMessageDialog(f,"SUCCESS\n Your Ticket is Issued and will be Printed");
                }
            }
        });
        JButton back=new JButton("Login page");
        back.setBounds(60,580,100,20);
        f.add(back);
        back.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                f.dispose();
                try{
                    FileWriter fstream = new FileWriter(System.currentTimeMillis() + "fout.txt");
                    BufferedWriter out = new BufferedWriter(fstream);
                    out.write("NAME = "+text1.getText());
                    out.write("\n");
                    out.write("age = "+text2.getText());
                    out.write("\n");
                    out.write("Gender ="+ch3.getItem(ch3.getSelectedIndex()));
                    out.write("\n");
                    out.write("Mobile no : "+text15.getText());
                    out.write("\n");
                    out.write("modE of payment ="+ch2.getItem(ch2.getSelectedIndex()));
                    out.write("\n");
                    out.close();
                }
                catch (Exception e1){
                    System.err.println("Error: " + e1.getMessage());
                }new BT();
            }
        });
        JLabel l8=new JLabel("  Login Page");
        l8.setBounds(50,550,400,30);
        f.add(l8);
        f.setSize(500,800);
        f.setLayout(null);
        f.setVisible(true);
        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
